// in this module , we are going to keep a array for the editors in the webpage

"use strict";
(function() {
/*
(function() {
    jQuery.noConflict();
    $ = function(selector,context) { 
        return new jQuery.fn.init(selector,context||example.doc); 
    };
    $.fn = $.prototype = jQuery.fn;

    example = new function(){};
    example.log = function() { 
        Firebug.Console.logFormatted(arguments,null,"log"); 
    };
    example.run = function(doc,aEvent) {
        // Check for website
        if (!doc.location.href.match(/^http:\/\/(.*\.)?stackoverflow\.com(\/.*)?$/i))  
            return;

        // Check if already loaded
        if (doc.getElementById("plugin-example")) return;

        // Setup
        this.win = aEvent.target.defaultView.wrappedJSObject;
        this.doc = doc;

        // Hello World
        this.main = main = $('<div id="plugin-example">').appendTo(doc.body).html('Example Loaded!');
        main.css({ 
            background:'#FFF',color:'#000',position:'absolute',top:0,left:0,padding:8
        });
        main.html(main.html() + ' - jQuery <b>' + $.fn.jquery + '</b>');
    };

    // Bind Plugin
    var delay = function(aEvent) { 
        var doc = aEvent.originalTarget; setTimeout(function() { 
            example.run(doc,aEvent); 
        }, 1); 
     };
    var load = function() { 
        gBrowser.addEventListener("DOMContentLoaded", delay, true); 
    };
    window.addEventListener("pageshow", load, false);

})();
*/

const PROJECT_NAME_PREFIX   = "FBM";
const INTEGRATING_ROLE_NAME = "_integerating_role_";
const ROLE_NAME_TO_BOX   = "to_box_";
const ROLE_NAME_EDIT_BOX = "edit_box_";
const ROLE_NAME_SEND_BOX = "send_box_";
const ROLE_NAME_SEND_BY_KEYPRESS_ENTER = "keypress_enter";
const ROLE_NAME_SEND_BY_MOUSE_CLICK = "mouse_click";
//const FN_INTEGRATING_ATTR_NAME = "fn-integrating";
//const FN_INTEGRATING_ATTR_VALUE = "emailbody";
//new_message_editor_group.editor.removeAttr("fn-integrating") == "emailbody";

// config:
//1 facebook message new 
// div id="pagelet_web_messenger" -- a good starting point
//editor : textarea : name="message_body", 
//send button : input value="Send" type="submit"
//tobox : td #text="To:" this element's next sibling element

//common 
var selector_editor = 'textarea[name="message_body"]';
var selector_sendbox = 'input[value="Send"][type="submit"]';
var selector_tobox = "//td[contains(.,'To:')]";

var charstoformid = '_0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
function uniqID(idlength) {
    //var charstoformid = '_0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
    if (! idlength) {
        idlength = Math.floor(Math.random() * charstoformid.length);
    }
    var uniqid = '';
    for (var i = 0; i < length; i++) {
        uniqid += charstoformid[Math.floor(Math.random() * charstoformid.length)];
    }
    return uniqid;
}
//common 
function log( msg)
{
	console.log("*****" + msg  );
}

var new_message_editor_group = 
{
	"id":null,
	"editor": null, 
	"sendbox": null, 
	"tobox": null, 
};

function find_Editor_group()
{
  var a_id = uniqID(20);
  var role_name = PROJECT_NAME_PREFIX + INTEGRATING_ROLE_NAME + a_id;
 // find editor
  if(!new_message_editor_group.editor)
  {
	  var editors$ = $(selector_editor);
  
	  var log_str = "find edtiors count is : " ;
	  log_str += editors$.length;
	  self.port.emit("getEditor", log_str + " " +a_id );
  
	  if(editors$.length == 1)//shoult there is only one
	  {
		  editors$.attr(role_name, ROLE_NAME_EDIT_BOX);
		  //editors$.attr(FN_INTEGRATING_ATTR_NAME,FN_INTEGRATING_ATTR_VALUE);
		  new_message_editor_group.editor = editors$;
		  
		  editors$.get(0).wrappedJSObject.fnhookedFlag = true; 
		  

		  new_message_editor_group.id = a_id;
	  }
  }
  
  //find send button
  if(!new_message_editor_group.sendbox)
  {
	  var send_boxes$ = $(selector_sendbox);
  
	  var log_str = "find sendbox count is : " ;
	  log_str += send_boxes$.length;
	  self.port.emit("getEditor", log_str + " " +a_id );
  
	  if(send_boxes$.length == 1)//shoult there is only one
	  {
		  send_boxes$.attr(role_name, ROLE_NAME_SEND_BOX);
		  new_message_editor_group.sendbox = send_boxes$;
		  hook_Send_box();
	  }
  }
  
  //recepient box
  if(!new_message_editor_group.tobox)
  {
	  var to_boxes$ =  $.xpath(selector_tobox).next("td");
	  var log_str = "find to_boxe count is : " ;
	  log_str += to_boxes$.length;
	  self.port.emit("getEditor", log_str + " " +a_id );
  
	  if(to_boxes$.length == 1)//shoult there is only one
	  {
		to_boxes$.attr(role_name, ROLE_NAME_TO_BOX);
		new_message_editor_group.tobox = to_boxes$;
		//test code
		var to_boxes_hide_span$ = $('<span>fntest003@gmail.com</sapen>').hide().appendTo(to_boxes$);

	  }
  }

  
  find_Editor_group_test(a_id);
}

function clean_Editor_group()
{
  // editor
	var role_name = PROJECT_NAME_PREFIX + INTEGRATING_ROLE_NAME + new_message_editor_group.id;
	if( new_message_editor_group.editor)
	{
	    delete editors$.get(0).wrappedJSObject.fnhookedFlag;
	    
	    self.port.emit("getEditor- clean_Editor_group ", "editor_group.editor  " + new_message_editor_group.editor);
	    new_message_editor_group.editor.removeAttr(role_name);
	    //new_message_editor_group.editor.removeAttr(FN_INTEGRATING_ATTR_NAME)

	    self.port.emit("getEditor", "editors$ removeAttr +  " + role_name);
	    new_message_editor_group.editor = null;
	}

	if( new_message_editor_group.sendbox)
	{
	    unhook_Send_box();
	    new_message_editor_group.sendbox.removeAttr(role_name);
	    self.port.emit("getEditor", "sendbox$ removeAttr +  " + role_name);
	    new_message_editor_group.sendbox =  null;
	}

	if( new_message_editor_group.tobox)
	{
	    new_message_editor_group.tobox.removeAttr(role_name);
	    self.port.emit("getEditor", "tobox$ removeAttr +  " + role_name);
	    new_message_editor_group.tobox =  null;
	}
	
	clean_Editor_group_test();
}


function call_simulate_mouse_click( box_obj, timeout)
{
	if(!box_obj)
		return;
	setTimeout(function(){
			var getX = function( obj ) {
				if( obj == null ) {
				  return 0;
				} else {
				  return obj.offsetLeft + getX( obj.offsetParent );
				}
			  }
			  var getY = function( obj ) {
				if( obj == null ) {
				  return 0;
				} else {
				  return obj.offsetTop + getY( obj.offsetParent );
				}
			  }
			  var evt = document.createEvent("MouseEvents");
			  evt.initMouseEvent("mousedown", true, true, window,
				0, 0, 0, 0, 0, false, false, false, false, 0, null);
			  box_obj.dispatchEvent(evt);
			  
			//top : it is window object
			try{
				var x = getX( box_obj );//getX( top ) - getX( box_obj ), 
				var y = getY( box_obj );//getY( top ) - getY( box_obj ),
				evt = document.createEvent("MouseEvents");
				evt.initMouseEvent("mousemove", true, true, window,
					0, 0, 0, x,y, 
					false, false, false, false, 0, null);
				box_obj.dispatchEvent(evt);
			  }
			  catch(err)
			  {
			  //alert(err)
			  }

			var evt = document.createEvent("MouseEvents");
			evt.initMouseEvent("mouseup", true, true, window,
				  0, 0, 0, 0, 0, false, false, false, false, 0, null);
				box_obj.dispatchEvent(evt);
		}	, timeout);
}


function call_simulate_mouse_click_jquery( box_obj$, timeout)
{
	if(!box_obj$)
	    return;
	setTimeout(function(){
	    box_obj$.trigger('click');
	    //box_obj$.trigger('mousedown');
	    
	    //box_obj$.trigger('mousemove');
	    
	    //box_obj$.trigger('mouseup');

		}	, timeout);
}
function on_fnaction_over(evt)	
{
	try
	{
	    //alert("evt.attrName " + evt.attrName  + " evt.newValue" + evt.newValue )
	    if(evt.attrName == "fnremotehtmlreq-event-param"  )
	    {
		if(evt.newValue=="true" || evt.newValue == "false")
		{	
		    document.body.removeEventListener("DOMAttrModified",on_fnaction_over, false);
		    $(document.body).removeAttr("fnRemoteHtmlReq-event-param");
		    new_message_editor_group.tobox.removeAttr("fnRemoteHtmlReq-event-param");   
		    new_message_editor_group.editor.removeAttr("fnRemoteHtmlReq-event-param");   
		   if (evt.newValue=="true") {
			//should add invitation
			var untrustedEmails =  $(document.body).attr("fnRemoteHtmlReq-event-param-subvalue");
			$(document.body).removeAttr("fnRemoteHtmlReq-event-param-subvalue");
			if (untrustedEmails.length > 0) {
			    onprepare_send_invitation(untrustedEmails);
			}
			
		    }
		    //click the button again
		    call_simulate_mouse_click_jquery(  new_message_editor_group.sendbox, 300)
		}
	    }
	}
	catch(err)
	{
	    //alert(err)
	}
}
//my be in common
function tell_to_box( tobox)
{
    var transobj = {funname:"setReceiptobjForInivitation_forRemoteWebpage", param:null};    	        
    $(tobox).attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));                
    //$(tobox).trigger("fnRemoteHtmlReq-event") // is it work
    var event = document.createEvent("HTMLEvents");        
    event.initEvent("fnRemoteHtmlReq-event", true, false);            
    tobox.dispatchEvent(event);
	
	
	
}

function fill_a_recepient(editor, email )
{
    var transobj = {funname:"addReceiptsToAnInput_ForWebPage", param:email};    	        
    $(editor).attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));              
    //$(editor).trigger("fnRemoteHtmlReq-event") // is it work
    var event = document.createEvent("HTMLEvents");        
    event.initEvent("fnRemoteHtmlReq-event", true, false);            
    editor.dispatchEvent(event)   
    
}

function fill_recepients(editor, tobox)
{
       //	file the recepients
    var fnidFinder = new RegExp('(\\w+\\.)*\\w+@(\\w+\\.)+[A-Za-z]+', 'gm'); 
    var htmlString = tobox.innerHTML;
    
    var results = htmlString.match(fnidFinder);
    for(var counter = 0; counter < results.length; ++counter)
    {
	var theEmail = results[counter];
	fill_a_recepient(editor, theEmail );
    } 
}
//my be in common
function tell_editor(editor)
{
    var transobj = {funname:"setEditorobjForInivitation_forRemoteWebpage", param:null};    	        
    $(editor).attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));                
    //$(editor).trigger("fnRemoteHtmlReq-event") // is it work
    var event = document.createEvent("HTMLEvents");        
    event.initEvent("fnRemoteHtmlReq-event", true, false);            
	editor.dispatchEvent(event);
}
//my be in common
function trigger_preSending()
{
	var transobj = {funname:"SendInvitation_ForWebPage", param:null};    	        
	$(document.body).attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));                
	//$(document.body).trigger("fnRemoteHtmlReq-event") // is it work?
	var event = document.createEvent("HTMLEvents");        
	event.initEvent("fnRemoteHtmlReq-event", true, false);            
	document.body.dispatchEvent(event);
}
//my be in common
function onAfter_preSending_event(callback)
{
    document.body.addEventListener("DOMAttrModified", callback, false);   
}

function onprepare_send_invitation(untrustedEmails)
{
    var transobj = {funname:"AppenddInvitation_ForWebPage", param:untrustedEmails};    	        
    $(document.body).attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));                
    //$(document.body).trigger("fnRemoteHtmlReq-event") // is it work?
    var event = document.createEvent("HTMLEvents");        
    event.initEvent("fnRemoteHtmlReq-event", true, false);            
    document.body.dispatchEvent(event);
}

function on_mousedown(evt)
{
	//alert( 'on_mousedown ' + evt.target )		//input -- label --> label --> input
	
	if(!evt.target.hj_cocntrol || evt.target.hj_cocntrol == 0)
	{
		evt.target.hj_cocntrol = 1;
	}
	else
	{
		evt.target.hj_cocntrol = 0;
		return;
	}
					
	//onmouseup attribute is insert by other part of code, remove it , we call the insertInvitationFooter directly
	//var onmouseup_val = evt.target.getAttribute("onmouseup");
					
	//if(onmouseup_val === "try{fnInvitationSenderNamespace.insertInvitationFooter();}catch(err){alert(err);}")
	//{
	//	evt.target.removeAttribute("onmouseup");
	//}
	
	evt.stopPropagation();
	evt.preventDefault();
					
	try{
	    //alert( "new_message_editor_group.sendbox.get(0).parentNode ==  evt.target  "
	    //  + new_message_editor_group.sendbox.get(0).parentNode ==  evt.target);
	   // if (new_message_editor_group.sendbox.get(0).parentNode ==  evt.target )
	    {
	
		
	
		//alert('will call insertInvitationFooter');
		
		// i hope the steps likes this 
		
		//self.port.emit("before-send-message", "window url:" + window.location.pathname);
		
		//window.fnInvitationSenderNamespace is not in this sand box!!
		//alert(window.fnInvitationSenderNamespace);//.insertInvitationFooter();
		//1 set recepients
		//2 encypt content and get result
		//try add invitation
		{//set recepients
			// var transobj = {funname:"setReceiptobjForInivitation_forRemoteWebpage", param:null};    	        
			// new_message_editor_group.tobox.attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));                
			// var event = document.createEvent("HTMLEvents");        
			// event.initEvent("fnRemoteHtmlReq-event", true, false);            
			// new_message_editor_group.tobox.get(0).dispatchEvent(event);
			tell_to_box(new_message_editor_group.tobox.get(0))
		
		}
		{//set editor
			tell_editor( new_message_editor_group.editor.get(0) )
			// var transobj = {funname:"setEditorobjForInivitation_forRemoteWebpage", param:null};    	        
			// new_message_editor_group.editor.attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));                
			// var event = document.createEvent("HTMLEvents");        
			// event.initEvent("fnRemoteHtmlReq-event", true, false);            
			// new_message_editor_group.editor.get(0).dispatchEvent(event);
		}
		
		    fill_recepients( new_message_editor_group.editor.get(0), new_message_editor_group.tobox.get(0) )
		
		{//trigger  //fnInvitationSenderNamespace.insertInvitationFooter();
			trigger_preSending()
			// var transobj = {funname:"SendInvitation_ForWebPage", param:null};    	        
			// $(document.body).attr("fnRemoteHtmlReq-event-param", JSON.stringify(transobj));                
			// var event = document.createEvent("HTMLEvents");        
			// event.initEvent("fnRemoteHtmlReq-event", true, false);            
			// document.body.dispatchEvent(event);
		}
		
		//document.body.addEventListener("DOMAttrModified", on_fnaction_over, false);   
		onAfter_preSending_event(on_fnaction_over);
	    }
	}
	catch( err )
	{
	    //alert(err);
	}
					
	//simulate a mosue click
	//call_simulate_mouse_click(evt.target.parentNode,10);
	//call_simulate_mouse_click_jquery($(evt.target),10)
}

function hook_Send_box()
{
	if( new_message_editor_group.sendbox)
	{
		var send_obj = new_message_editor_group.sendbox;

		if(send_obj)
		{
			//intercept the event in caputuring phase
			//intercept the parent node of the div, because when user clicks the parent node, the message is send out too.
			//send_obj.parentNode
			//send_obj.get(0).parentNode.parentNode.parentNode.addEventListener('mousedown' , on_mousedown,true);
			//send_obj.get(0).parentNode.addEventListener('mousedown' , on_mousedown,true);
			send_obj.get(0).parentNode.addEventListener('click' , on_mousedown,true);
			//send_obj.get(0).parentNode.addEventListener('mouseup' , on_mousedown,true);
			//$(document.body).on("click", send_obj.get(0), on_mousedown);
			
			//$(document.body).on("click", selector_sendbox+:parent, on_mousedown); // I CAN NOT USE send_obj.get(0) as a selector!!!
			//$(document.body).on("mousedown", selector_sendbox, on_mousedown); // I CAN NOT USE send_obj.get(0) as a selector!!!  , can not block
			
			
			//console.log("** send_obj.addEventListener('mousedown' , on_mousedown,true)***"  );
		}
	}
}

function unhook_Send_box()
{
	if( new_message_editor_group.sendbox)
	{
		var send_obj = new_message_editor_group.sendbox;

		if(send_obj)
		{
			//intercept the event in caputuring phase
			//intercept the parent node of the div, because when user clicks the parent node, the message is send out too.
			//send_obj.parentNode
			//send_obj.get(0).parentNode.removeEventListener('mousedown' , on_mousedown,true);
			send_obj.get(0).parentNode.removeEventListener('click' , on_mousedown,true);
			//send_obj.get(0).parentNode.removeEventListener('mouseup' , on_mousedown,true);
			
			//send_obj.get(0).parentNode.removeEventListener('mousedown' , on_mousedown, true);
			//alert('$(document).off("click", send_obj, on_mousedowngg')
			//$(document.body).off("mousedown", on_mousedown); // I CAN NOT USE selector_sendbox as a selector  because the page change it!!!
			//$(document.body).off("click", send_obj.get(0), on_mousedown);
			//$(document.body).off("click", selector_sendbox, on_mousedown);
			//console.log("** send_obj.removeEventListener('mousedown' , on_mousedown,true)***"  );
		}
	}
}

function find_Editor_group_test(a_id)
{
	//to do : plan to open a panel or  frame to tell the manager the page status with QUint
}

function clean_Editor_group_test()
{
    //to do : plan to  tell the manager the page status in a panel or a frame  with QUint
}

function is_my_page(url_spec)
{
    var reg_URL = /^https:\/\/www.facebook.com\/messages\/new(\/?)/ ;
    var match = reg_URL.test( url_spec );
    return match;
}
self.port.on("send-message", function(data) {
	if( is_my_page(data) && new_message_editor_group.sendbox)
	{
		var send_obj = new_message_editor_group.sendbox;

		if(send_obj)
		{
			call_simulate_mouse_click_jquery(send_obj.parent(), 1 );
		}
	}
});

self.port.on("getEditors", function(url_spec) {

	//"https://www.facebook.com/messages/"  "https://www.facebook.com/messages" , "https://www.facebook.com/messages/new , "https://www.facebook.com/messages/new/: not match
	//"https://www.facebook.com/messages/xxxxxx"  match
	if( is_my_page(url_spec) )
	{
		if(document.URL == url_spec)
		{
			//self.port.emit("getEditor", "url_spec == https://www.facebook.com/messages/new");
			//self.port.emit("getEditor", "document url:" + document.URL);
			//self.port.emit("getEditor", "window url:" + window.location.pathname);
			find_Editor_group();
			//self.port.emit("getEditor", "url_spec == https://www.facebook.com/messages/new");
		}
	}
	else
	{
		clean_Editor_group();
	}
	
	/*var log = " this == ";
	for(var b in this)
	{
		log += b;
		log += "\n";
	}


	alert( "this type " + log)*/
	
	/*var log = " self == ";
	for(var b in self)
	{
		log += b;
		log += "\n";
	}


	alert( "self type " + log)
	self property : port
	postMessage
	on
	once
	removeListener
	so it is a worker
	*/

    /*if ("onhashchange" in window) {
         self.port.emit("getEditor", "The browser supports the hashchange event!");
    }
 
    function locationHashChanged() {
    if (location.hash === "#somecoolfeature") {
        somecoolfeature();
        }
    }
     window.onhashchange = locationHashChanged;

	$(window).bind( 'popstate', 
        function(e) { 
            alert("ssss")
            self.port.emit("getEditor", e);
            }
        );
    
    $(document).bind( 'DOMContentLoaded', 
        function(e) { 
            alert("ssss")
            self.port.emit("getEditor", e);
            }
        );
  */
});



//li class="fbTimelineUnit lastCapsule fbTimelineTwoColumn clearfix fbTimelineComposerCapsule"
//-- div class="timelineUnitContainer fbTimelineComposerUnit"
//----div data-referrer="timeline_composer"
//------ ... div class="uiMentionsInput _11a"
// ------- ...  textarea class="uiTextareaAutogrow input autofocus mentionsTextarea textInput DOMControl_placeholder" name="xhpc_message_text"

/*

form rel="async" action="/ajax/updatestatus.php" method="post" onsubmit="return window.Event &amp;&amp; Event.__inlineSubmit &amp;&amp; Event.__inlineSubmit(this,event)" 
id="u_0_1g"><input type="hidden" name="fb_dtsg" value="AQAqKbtk" autocomplete="off">

*/
})();

///for comment reply:
///textarea class="textInput mentionsTextarea uiTextareaAutogrow uiTextareaNoResize UFIAddCommentInput"  name="add_comment_text_text"